import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-header',
  templateUrl: './one-header.component.html',
  styleUrls: ['./one-header.component.css']
})
export class OneHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
