
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent2',
  templateUrl: './parent2.component.html',
  styleUrls: ['./parent2.component.css']
})
export class Parent2Component implements OnInit {
  counter_value_at_parent2:any// Should not be initialized

  constructor() { }

  ngOnInit(): void {
  }
  receiveFromChild2(value1:any) {
    this.counter_value_at_parent2 = value1
  }

}
