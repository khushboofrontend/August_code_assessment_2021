import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-c4',
  templateUrl: './one-c4.component.html',
  styleUrls: ['./one-c4.component.css']
})
export class OneC4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
