import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private empService:EmployeeService) { }

  ngOnInit(): void {// Life cycle hooks
    this.getEmployeeList();
  }

  getEmployeeList = () => {
    this.empService.getUsers().subscribe(
      (result) => {
        this.employees = <any>result;
        this.total_no_of_records = this.employees.length
      },
      (error) => {
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

  delete1Employe(employee:any) {
    if(window.confirm(`Are you sure to delete the record with Email Id = ${employee.id}?`)) {
      this.empService.deleteEmployee(employee.id)
      .subscribe( data => {
        this.employees = this.employees.filter(e => e !== employee);// Refresh the users Array / remove the deleted record from Array
      })
    }

  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}
