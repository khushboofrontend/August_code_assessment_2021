import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent1',
  templateUrl: './parent1.component.html',
  styleUrls: ['./parent1.component.css']
})
export class Parent1Component implements OnInit {
  counter:number = 0

  ngOnInit(): void {
  }

  increment() {
    this.counter += 1
  }

  decrement() {
    this.counter -= 1
  }
}
