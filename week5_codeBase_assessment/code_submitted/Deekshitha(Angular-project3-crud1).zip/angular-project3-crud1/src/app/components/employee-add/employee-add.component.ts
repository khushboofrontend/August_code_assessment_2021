import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from './../../services/employee.service';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  id:any
  employee_name:string = ''
  date_of_birth:string = ''
  hand_phone_no:any
  address:string=''
  message = ''
  constructor(private router:Router, private employeeService:EmployeeService) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body = "employee_name=" + this.employee_name 
        + "&date_of_birth=" + this.date_of_birth 
        + "&hand_phone_no=" + this.hand_phone_no;
        + "&address=" + this.address;
    this.employeeService.createEmployee(body)
      .subscribe( data => {
        this.router.navigate(['employeelist']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }

}
