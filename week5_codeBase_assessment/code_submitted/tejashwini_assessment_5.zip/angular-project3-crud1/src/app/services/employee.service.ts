import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  apiUrl:string = "http://localhost:5555/employee/"
  constructor(private http: HttpClient) { }
  getEmployee() {
    return this.http.get(this.apiUrl);
  }
  createEmployee(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.apiUrl, body, {headers: headers, responseType:'text'});
  }
  deleteEmployee(employeeid:any) {
    return this.http.delete(this.apiUrl + employeeid);
  }
  getEmployeeById(employeeid:any) {
    return this.http.get<any>(this.apiUrl + employeeid);
  }

  updateEmployee(body: string, employeeid: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.put(this.apiUrl + employeeid, body, {headers: headers, responseType:'text'});
  }
}
