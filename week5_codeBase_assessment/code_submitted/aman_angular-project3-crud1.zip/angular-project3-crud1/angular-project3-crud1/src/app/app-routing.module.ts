import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { EmpListComponent } from './components/emp-list/emp-list.component';
import { EmpAddComponent } from './components/emp-add/emp-add.component';

import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';

const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'emplist', component:EmpListComponent},

  {path:'empadd', component:EmpAddComponent},

  {path:'contact', component:ContactUsComponent},
  {path:'about', component:AboutUsComponent},
  {path:'**', component:PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
