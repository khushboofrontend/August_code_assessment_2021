import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  
  id:any
  employee_name:string = ''
  date_of_birth:any
  hand_phone_no:any
  address:string = ''
  message = ''

  constructor(private http:HttpClient, private router:Router) { }

  ngOnInit(): void {
  }

  addemployee = () => {
    //alert('You submitted the form')
    let obj = {id:this.id, employee_name:this.employee_name, date_of_birth:this.date_of_birth, hand_phone_no:this.hand_phone_no, address:this.address}

    if(this.employee_name != '' && this.date_of_birth != '' && this.hand_phone_no!='' && this.id!='' && this.address != '') {
      this.http.post("http://localhost:5555/employee", obj).subscribe(
        (result) => {
          // console.log('Inserted')
          // console.log(result)
          // redirect to employee-list page
          this.router.navigate(['employeelist']);
        }
      )
    }

  }

  clearMessage() {
    this.message = ''
  }

}
