import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-home',
  templateUrl: './one-home.component.html',
  styleUrls: ['./one-home.component.css']
})
export class OneHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
