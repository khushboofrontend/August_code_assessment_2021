import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent1',
  templateUrl: './parent1.component.html',
  styleUrls: ['./parent1.component.css']
})
export class Parent1Component implements OnInit {
  counter_value_at_parent1:any
  counter:number = 0

  increment_by1() {
    this.counter += 1
  }

  decrement_by1() {
    this.counter -= 1
  }
  constructor() { }

  ngOnInit(): void {
  }

}


