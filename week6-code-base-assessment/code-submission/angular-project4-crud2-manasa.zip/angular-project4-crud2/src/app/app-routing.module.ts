import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomePageComponent } from './component/home-page/home-page.component';
import { ContactUsComponent } from './component/contact-us/contact-us.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { UserAddComponent } from './component/user-add/user-add.component';
import { UserListComponent } from './component/user-list/user-list.component';
import { UserEditComponent } from './component/user-edit/user-edit.component';
const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'home-page', component:HomePageComponent},
  {path:'user-add', component:UserAddComponent},
  {path:'user-list', component:UserListComponent},
  {path:'homepage', component:HomePageComponent},
  {path:'contact-us', component:ContactUsComponent},
  {path:'about-us', component:AboutUsComponent},
  {path:'user-edit/:id', component:UserEditComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
