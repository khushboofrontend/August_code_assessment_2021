import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EmpserviceService } from 'src/app/services/empservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css']
})
export class UserAddComponent implements OnInit {
  id:any
  employee_name:string = ''
  date_of_birth:any = ''
  hand_phone_no:any = ''
  address:string = ''
  message = ''

  constructor(private empService:EmpserviceService, private router:Router) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body =  "id=" + this.id 
    +"&employee_name=" + this.employee_name 
        + "&date_of_birth=" + this.date_of_birth 
        + "&hand_phone_no=" + this.hand_phone_no
        + "&address=" + this.address;
    this.empService.createUser(body)
      .subscribe( data => {
        this.router.navigate(['userlist']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }}


