import { Component, OnInit } from '@angular/core';
import { EmployeeService } from "./../../services/employee.service";

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employee:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private employeeService:EmployeeService) { }

  ngOnInit(): void {
    this.getEmployeeList()
  }

  getEmployeeList = () => {
    this.employeeService.getEmployeeList().subscribe(
      (result:any) => {
        this.employee = <any>result;
        this.total_no_of_records = this.employee.length
      },
      (error:any) => {
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }
  
}


