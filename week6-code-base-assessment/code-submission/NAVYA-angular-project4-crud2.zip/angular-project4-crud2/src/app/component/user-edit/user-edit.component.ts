import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {
  id:any
  employee_name:string = ''
  qualification:string=''
  date_of_birth:any
  resident_phone_no :any
  address:any
  message = ''
  

  constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    })
    this.http.get<any>("http://localhost:5555/employee/" + this.id).subscribe(// http://localhost:5555/user/2
      (result) => {
        this.id = result.id;
        this.employee_name = result.employee;
        this.qualification = result.qualification;
        this.date_of_birth = result.date_of_birth;
        this.resident_phone_no = result.resident_phone_no;
        this.address = result.address;
      }
    )

  }

  editUser() {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    //let headers = new HttpHeaders({'Content-Type': 'application/json'});

    //let obj = {id:this.id, user_name:this.user_name, email_id:this.email_id, pass_word:this.pass_word}

        var body = "id=" + this.id 
        + "&employee_name=" + this.employee_name 
        + "&qualification=" + this.qualification 
        + "&date_of_birth=" + this.date_of_birth
        + "&resident_phone_no=" + this.resident_phone_no
        + "&address=" + this.address;

    let url = "http://localhost:5555/employee/" + this.id

    this.http.put(url, body, {headers:headers, responseType:'text'}).subscribe(
          data => {
            this.router.navigate(['user-list']);
          },
          error => {
            alert(error);
          });
  
    //this.http.put("http://localhost:5555/user/1/", obj, {headers:headers, responseType:'text'});
  }
}