import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employee:any[] = []

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.getEmployeeList()
  }

  
  getEmployeeList = () => {
    this.http.get("http://localhost:5555/employee").subscribe(
      (result) => {
        this.employee = <any>result
        //console.log(result)
      }
    )
  }
}
