import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AboutUsComponent } from './components/about-us/about-us.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { EmployeeAddComponent } from './components/employee-add/employee-add.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { EmployeeEditComponent } from './components/employee-edit/employee-edit.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { SiteLayoutComponent } from './components/site-layout/site-layout.component';
import { EmployeeComponent } from './services/employee/employee.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
const routes: Routes = [
 { path:'', component:HomePageComponent},
 { path:'contact', component:ContactUsComponent},
 { path:'about', component:AboutUsComponent},
 { path:'employeeadd', component:EmployeeAddComponent},
 { path:'employeelist', component:EmployeeListComponent},
 { path:'site-layout', component:SiteLayoutComponent},
 { path:'header', component:HeaderComponent},
 { path:'footer', component:FooterComponent},
 { path:'employeeedit/:id', component:EmployeeEditComponent, pathMatch:'full'},
 {path:'**', component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
