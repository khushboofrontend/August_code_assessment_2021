import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-c2',
  templateUrl: './one-c2.component.html',
  styleUrls: ['./one-c2.component.css']
})
export class OneC2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
