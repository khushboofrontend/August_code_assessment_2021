import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Parent1Component } from './components/parent1/parent1.component';
import { Child1Component } from './components/child1/child1.component';
import { Parent2Component } from './components/parent2/parent2.component';
import { Child2Component } from './components/child2/child2.component';
// import { HeaderComponent } from './header/header.component';
// import { FooterComponent } from './footer/footer.component';
import { SiteLayoutComponent } from './components/site-layout/site-layout.component';


const routes: Routes = [
  {path:'parent1', component:Parent1Component},
  {path:'child1', component:Child1Component},
  {path:'parent2', component:Parent2Component},
  {path:'child2', component:Child2Component},
  // {path:'header', component:HeaderComponent},
  // {path:'footer', component:FooterComponent},
  {path:'site-layout', component:SiteLayoutComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
