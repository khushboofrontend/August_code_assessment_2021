import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  apiUrl:string = "http://localhost:5555/employee/"

  constructor(private http: HttpClient) { }

  getemp() {
    return this.http.get(this.apiUrl);
  }

  createemp(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.apiUrl, body, {headers: headers, responseType:'text'});
  }

  getEmpById(userid:any) {
    return this.http.get<any>(this.apiUrl + userid);
  }

 
}