import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from './../../services/employee.service';
import {first} from "rxjs/operators"
@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {

  id:any
  employee_name:string = ''
  date_of_birth:any
  qualification:string=''
  resident_phone_number:any
  address:string=''
  message =''
  constructor(private route:ActivatedRoute, private router: Router, private employeeService:EmployeeService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params =>{
      this.id = params['id']
    })
  
  this.employeeService.getEmployeeById(this.id)
      .subscribe( data1 => {
        console.log(data1)
        this.employee_name = data1.employee_name;
        this.date_of_birth=data1.date_of_birth;
        this.qualification=data1.qualification;
        this.resident_phone_number=data1.resident_phone_number;
        this.address=data1.address;
      },
      error => {
        alert(error);
      });
  }

  editEmployee() {
    var body = "id=" + this.id 
        + "&employee_name=" + this.employee_name 
        + "&date_of_birth=" + this.date_of_birth
        + "&qualification=" +this.qualification
        + "&resident_phone_number=" +this.resident_phone_number 
        + "&address=" + this.address;
    this.employeeService.updateEmployee(body, this.id)
      .subscribe(
        data => {
          this.router.navigate(['employeelist']);
        },
        error => {
          alert(error);
        });
  }
}
