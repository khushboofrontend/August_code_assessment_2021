import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SitelayoutComponent } from './sitelayout/sitelayout.component';
import { FooterComponent } from './footer/footer.component';
import { Child1Component } from './child1/child1.component';
import { Child2Component } from './child2/child2.component';
import { Parent1Component } from './parent1/parent1.component';
import { Parent2Component } from './parent2/parent2.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SitelayoutComponent,
    FooterComponent,
    Child1Component,
    Child2Component,
    Parent1Component,
    Parent2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [SitelayoutComponent]
})
export class AppModule { }
