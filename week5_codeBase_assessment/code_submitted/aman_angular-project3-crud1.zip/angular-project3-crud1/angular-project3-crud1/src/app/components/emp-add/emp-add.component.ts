import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
  // Dependency Injection

@Component({
  selector: 'app-emp-add',
  templateUrl: './emp-add.component.html',
  styleUrls: ['./emp-add.component.css']
})
export class EmpAddComponent implements OnInit {

    id:any
    employee_name:string = ''
    date_of_birth:number = 0
    hand_phone_no:any
    address:string=''
    message = ''
  
  constructor(private http: HttpClient, private router:Router) { }// Dependency Injection

  ngOnInit(): void {
  }                            

  addEmployee = () => {
    let obj = {id:this.id, employee_name:this.employee_name, date_of_birth:this.date_of_birth, hand_phone_no:this.hand_phone_no,address:this.address}
    this.http.post("http://localhost:5555/employee", obj).subscribe(
      (result) => {
        console.log('Inserted')
        console.log(result)
      }
    )
    this.router.navigate(['emplist']);
  }

  clearMessage() {
    this.message = ''
  }

}
