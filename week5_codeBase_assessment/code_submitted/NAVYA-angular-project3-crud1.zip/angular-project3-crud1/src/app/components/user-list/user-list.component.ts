import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private http: HttpClient) { }// Dependency Injection

  ngOnInit(): void {// Life cycle hooks
    this.getUserList()
  }

  getUserList = () => {
    this.http.get("http://localhost:5555/employee").subscribe(
      (result) => {
        this.users = <any>result
        this.total_no_of_records = this.users.length
        //console.log(result)
      }
    )
  }

  delete1User(user:any) {
    if(window.confirm(`Are you sure to delete the record with Email Id = ${user.email_id}?`)) {
      this.http.delete("http://localhost:5555/user/"+user.id).subscribe( data => {
        this.users = this.users.filter(u => u !== user);// Refresh the users Array / remove the deleted record from Array
        //alert('Deleted')
        }
      )
    }
  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}