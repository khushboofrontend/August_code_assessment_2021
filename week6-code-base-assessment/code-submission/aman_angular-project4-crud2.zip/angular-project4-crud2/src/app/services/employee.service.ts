import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  apiUrl:string = "http://localhost:5555/employee/"
  constructor(private http: HttpClient) { }

  getUsers() {
    return this.http.get(this.apiUrl);
  }

  createUser(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.apiUrl, body, {headers: headers, responseType:'text'});
  }

  deleteEmployee(empid:any) {
    return this.http.delete(this.apiUrl + empid);
  }

  getEmployeeById(empid:any) {
    return this.http.get<any>(this.apiUrl + empid);
  }

  updateEmployee(body: string, empid: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.put(this.apiUrl + empid, body, {headers: headers, responseType:'text'});
  }


}
