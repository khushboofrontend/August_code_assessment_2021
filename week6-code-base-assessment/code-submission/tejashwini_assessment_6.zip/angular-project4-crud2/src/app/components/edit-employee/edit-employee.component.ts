import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';
import {first} from "rxjs/operators";
@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
  id:any
  employee_name:string = ''
  qualification:string=''
  date_of_birth:any 
  resident_phone_no:any 
  address: string=''
  message = ''
  constructor(private route: ActivatedRoute, private router: Router, private employeeService:EmployeeService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
  })

  this.employeeService.getEmployeeById(this.id)
      .subscribe( data1 => {
        console.log(data1)
        this.employee_name = data1.employee_name;
        this.qualification = data1.qualification;
        this.date_of_birth  = data1.date_of_birth;
        this.resident_phone_no = data1.resident_phone_no;
        this.address=data1.address;
      },
      error => {
        alert(error);
      }
      );
    }

  editEmployee() {
    var body = "&id=" + this.id 
        + "&employee_name=" + this.employee_name
        + "&qualification=" + this.qualification
        + "&date_of_birth=" + this.date_of_birth 
        + "&resident_phone_no=" + this.resident_phone_no
        + "&address=" + this.address;
    this.employeeService.updateEmployee(body, this.id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['employee-list']);
        },
        error => {
          alert(error);
        });
  }


}
