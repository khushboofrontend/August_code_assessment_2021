import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from "./../../services/empservice.service";


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  employee:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private empservice: EmpserviceService) { }

  ngOnInit(): void {// Life cycle hooks
    this.getUserList()
  }

  getUserList = () => {
    this.empservice.getUsers().subscribe(
      (result) => {
        this.employee = <any>result;
        this.total_no_of_records = this.employee.length
      },
      (error) => {
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }
}