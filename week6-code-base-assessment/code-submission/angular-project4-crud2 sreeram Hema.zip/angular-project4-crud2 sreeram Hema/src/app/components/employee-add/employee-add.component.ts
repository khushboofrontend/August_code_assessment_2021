import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from './../../services/employee.service';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {
  id:any
  employee_name:string = ''
  date_of_birth:any
  qualification:string=''
  resident_phone_number:any
  address:string=''
  message =''

  constructor(private router:Router, private employeeService:EmployeeService) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body = "employee_name=" + this.employee_name 
        + "&date_of_birth=" + this.date_of_birth
        + "&qualification=" + this.qualification 
        + "&resident_phone_number=" + this.resident_phone_number
        + "&address=" + this.address;
    this.employeeService.createEmployee(body)
      .subscribe( data => {
        this.router.navigate(['employeelist']);
      },
      (error) => {
        this.message = error.error
      });
  }

}
