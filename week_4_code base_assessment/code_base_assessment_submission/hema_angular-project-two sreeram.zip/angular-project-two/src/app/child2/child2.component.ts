import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
   selector: 'app-child2',
   templateUrl: './child2.component.html',
   styleUrls: ['./child2.component.css']
 })
 export class Child2Component implements OnInit {
  counter = 0
  @Output() event_emitter1 = new EventEmitter
  increment_by1() {
    this.counter += 1
    this.event_emitter1.emit(this.counter)
  }
  decrement_by1() {
    this.counter -= 1
    this.event_emitter1.emit(this.counter)
  }
  constructor() { }

  ngOnInit(): void {
  }

}


