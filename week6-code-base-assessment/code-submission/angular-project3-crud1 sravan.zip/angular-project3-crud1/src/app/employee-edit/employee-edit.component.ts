import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {
  id:any
  employee_name:string = ''
  qualification:string=''
  date_of_birth:any
  resident_phone_number :any
  address:any
  message = ''

  constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    })
    this.http.get<any>("http://localhost:5555/employee/" + this.id).subscribe(// http://localhost:5555/user/2
      (result) => {
        this.id = result.id;
        this.employee_name = result.employee;
        this.qualification = result.qualification;
        this.date_of_birth = result.date_of_birth;
        this.resident_phone_number = result.resident_phone_number;
        this.address = result.address;
      }
    )

  }

  editEmployee() {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    //let headers = new HttpHeaders({'Content-Type': 'application/json'});

    //let obj = {id:this.id, user_name:this.user_name, email_id:this.email_id, pass_word:this.pass_word}

        var body = "id=" + this.id 
        + "&employee_name=" + this.employee_name 
        + "&qualification=" + this.qualification 
        + "&date_of_birth=" + this.date_of_birth
        + "&resident_phone_number=" + this.resident_phone_number
        + "&address=" + this.address;

    let url = "http://localhost:5555/employee/" + this.id

    this.http.put(url, body, {headers:headers, responseType:'text'}).subscribe(
          data => {
            this.router.navigate(['employee-list']);
          },
          error => {
            alert(error);
          });
  
    //this.http.put("http://localhost:5555/user/1/", obj, {headers:headers, responseType:'text'});
  }
}