import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  id:any
  employee_name:string = ''
  date_of_birth:any 
  hand_phone_no:any 
  address: string=''
  message = ''
  
  constructor(private router:Router, private userService:EmployeeService) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body = "employee_name=" + this.employee_name
        + "&date_of_birth=" + this.date_of_birth
        + "&hand_phone_no=" + this.hand_phone_no
        + "&address=" + this.address;
    this.userService.createEmployee(body)
      .subscribe( data => {
        this.router.navigate(['employee-list']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }
}
