import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmpService } from "./../../service/emp.service";


@Component({
  selector: 'app-emp-add',
  templateUrl: './emp-add.component.html',
  styleUrls: ['./emp-add.component.css']
})
export class EmpAddComponent implements OnInit {

  id:any
  employee_name:string = ''
  qualification:string =''
  date_of_birth:any = ''
  resident_phone_no:any
  address: any =''
  message = ''

  constructor(private router:Router, private empService:EmpService) { }// Dependency Injection

  ngOnInit(): void {
  }

  addEmp = () => {
    var body = "id=" + this.id
        + "&employee_name=" + this.employee_name 
        + "&qualification=" + this.qualification
        + "&date_of_birth=" + this.date_of_birth
        + "&resident_phone_no=" + this.resident_phone_no
        + "&address=" + this.address;
    this.empService.createemp(body)
      .subscribe( data => {
        this.router.navigate(['emplist']);
      },
      (error) => {
        this.message = error.error
        alert("Id already exists")
      });
  }

  clearMessage() {
    this.message = ''
  }
}