import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-site-layout',
  templateUrl: './one-site-layout.component.html',
  styleUrls: ['./one-site-layout.component.css']
})
export class OneSiteLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
