import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-footer',
  templateUrl: './one-footer.component.html',
  styleUrls: ['./one-footer.component.css']
})
export class OneFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
