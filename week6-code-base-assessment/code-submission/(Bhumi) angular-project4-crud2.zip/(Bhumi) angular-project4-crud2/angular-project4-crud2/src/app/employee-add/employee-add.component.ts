import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  id:any
  employee_name:string = ''
  qualification:string = ''
  date_of_birth:any = ''
  resident_phone_number=0
  address:any
  message=''

  constructor(private empService: EmployeeService, private router: Router) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body = "id=" + this.id
        + "&employee_name=" + this.employee_name
        +"qualification=" + this.qualification
        + "&date_of_birth=" + this.date_of_birth
        +"&resident_phone_number=" + this.resident_phone_number
        +"&address=" + this.address;
    this.empService.createEmployee(body)
      .subscribe( data => {
        this.router.navigate(['employee-list']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }

}
