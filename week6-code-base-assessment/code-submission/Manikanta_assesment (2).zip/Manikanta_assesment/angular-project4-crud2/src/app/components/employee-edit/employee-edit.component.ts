import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { EmployeeService } from "./../../services/employee.service";
@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {
  id:any
  employee_name:any
  date_of_birth:any
  resident_phone_no:any
  qualification:String=''
  address:any
  message:any
  constructor(private router:Router,private route: ActivatedRoute, private userService:EmployeeService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    })
  this.userService.getUserById(this.id)
  .subscribe( data1 => {
    console.log(data1)
    this.employee_name = data1.employee_name;
    this.qualification = data1.qualification;
    this.date_of_birth  = data1.date_of_birth;
    this.resident_phone_no = data1.resident_phone_no;
    this.address = data1.address;
  },
  error => {
    alert(error);
  });
}

empedit() {
var body = "id=" + this.id 
    + "&employee_name=" + this.employee_name 
    + "&qualification=" + this.qualification
    + "&date_of_birth=" + this.date_of_birth 
    + "&resident_phone_no=" + this.resident_phone_no 
    + "&address=" + this.address;
this.userService.updateUser(body, this.id)
  //.pipe(first())
  .subscribe(
    data => {
      this.router.navigate(['read']);
    },
    error => {
      alert("Id cannot be changed");
    });
}
}
