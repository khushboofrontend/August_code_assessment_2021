import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmpService } from "./../../service/emp.service";


@Component({
  selector: 'app-emp-add',
  templateUrl: './emp-add.component.html',
  styleUrls: ['./emp-add.component.css']
})
export class EmpAddComponent implements OnInit {

  id:any
  employee_name:string = ''
  date_of_birth:any = ''
  hand_phone_no:number = 0
  address: any =''
  message = ''

  constructor(private router:Router, private empService:EmpService) { }// Dependency Injection

  ngOnInit(): void {
  }

  addEmp = () => {
    var body = "id=" + this.id
        + "&employee_name=" + this.employee_name 
        + "&date_of_birth=" + this.date_of_birth
        + "&hand_phone_no=" + this.hand_phone_no
        + "&address=" + this.address;
    this.empService.createemp(body)
      .subscribe( data => {
        this.router.navigate(['emplist']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }
}