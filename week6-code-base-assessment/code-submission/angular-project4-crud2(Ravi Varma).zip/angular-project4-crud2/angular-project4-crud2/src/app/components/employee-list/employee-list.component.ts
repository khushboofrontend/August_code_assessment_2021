import { Component, OnInit } from '@angular/core';
import { EmployeeService } from "./../../services/employee.service";
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees:any[] = []
  total_no_of_records:any
  message = ''

  constructor(private employeeService: EmployeeService, private http: HttpClient) { }

  ngOnInit(): void {
    this.getEmployeeList()
  }

  getEmployeeList = () => {
    this.employeeService.getEmployees().subscribe(
      (result) => {
        this.employees = <any>result;
        this.total_no_of_records = this.employees.length
      },
      (error) => {
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }
  delete1Employee(employee:any) {
    if(window.confirm(`Are you sure to delete the record with Id = ${employee.id}?`)) {
      this.employeeService.deleteEmployee(employee.id)
        .subscribe( data => {
          this.employees = this.employees.filter(u => u !== employee);// Refresh the users Array / remove the deleted record from Array
        })
    }
  }
  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}
