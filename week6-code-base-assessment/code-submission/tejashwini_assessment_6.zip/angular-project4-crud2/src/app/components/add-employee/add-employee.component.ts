import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  id:any
  employee_name:string = ''
  qualification:string=''
  date_of_birth:any 
  resident_phone_no:any 
  address: string=''
  message = ''
  
  constructor(private router:Router, private userService:EmployeeService) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body = "id=" + this.id
        + "&employee_name=" + this.employee_name
        + "&qualification=" + this.qualification
        + "&date_of_birth=" + this.date_of_birth
        + "&resident_phone_no=" + this.resident_phone_no
        + "&address=" + this.address;
    this.userService.createEmployee(body)
      .subscribe( data => {
        this.router.navigate(['employee-list']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }
}
