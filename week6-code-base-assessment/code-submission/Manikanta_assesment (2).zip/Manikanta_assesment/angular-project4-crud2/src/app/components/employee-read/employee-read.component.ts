import { Component, OnInit } from '@angular/core';
import { EmployeeService } from "./../../services/employee.service";

@Component({
  selector: 'app-employee-read',
  templateUrl: './employee-read.component.html',
  styleUrls: ['./employee-read.component.css']
})
export class EmployeeReadComponent implements OnInit {

  employees:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private userService:EmployeeService) {
    console.log('constructor')
    //this.getUserList() this is not the right place to other methods / still you can do
  }

  ngOnInit(): void {// Life cycle hooks
    console.log('ngOnInit')
    this.getUserList()
  }

  ngOnDestroy() {
    console.log('ngOnDestroy')
  }

  getUserList = () => {
    this.userService.getUsers().subscribe(
      (result) => {
        this.employees = <any>result;
        this.total_no_of_records = this.employees.length
      },
      (error) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );
  }
    delete1User(user:any) {
      if(window.confirm(`Are you sure to delete the record with Email Id = ${user.email_id}?`)) {
        this.userService.deleteUser(user.id)
          .subscribe( data => {
            this.employees = this.employees.filter(u => u !== user);// Refresh the users Array / remove the deleted record from Array
          })
      }
    }
  

 
  


}
