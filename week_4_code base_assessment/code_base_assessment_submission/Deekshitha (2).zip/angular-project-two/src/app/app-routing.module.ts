import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Parent1Component } from './components/parent1/parent1.component';
import { Parent2Component } from './components/parent2/parent2.component';
import { Child1Component } from './components/child1/child1.component';
import { Child2Component } from './components/child2/child2.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';

const routes: Routes = [{path:'', component:Parent1Component},
{path:'parent2', component:Parent2Component},
{path:'child1', component:Child1Component},
{path:'child2', component:Child2Component},
{path:'**',component:PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
