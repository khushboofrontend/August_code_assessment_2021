import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-c1',
  templateUrl: './one-c1.component.html',
  styleUrls: ['./one-c1.component.css']
})
export class OneC1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
