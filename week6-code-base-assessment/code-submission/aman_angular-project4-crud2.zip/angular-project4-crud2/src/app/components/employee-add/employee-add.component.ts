import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  id:any
  employee_name:string = ''
  qualification:string=''
  date_of_birth:string = ''
  resident_phone_no:string = ''
  address:any
  message = ''

  id1:any

  constructor(private employeeService: EmployeeService, private router: Router) { }

  ngOnInit(): void {
  }

  addEmployee = () => {
    var body = "id=" + this.id
        +"&employee_name=" + this.employee_name 
        +"&qualification=" + this.qualification 
        + "&date_of_birth=" + this.date_of_birth 
        + "&resident_phone_no=" + this.resident_phone_no
        + "&address=" + this.address;
        console.log(this.addEmployee)
    this.employeeService.createUser(body)
      .subscribe( data => {
        this.router.navigate(['/emplist']);
      },
      (error) => {
        this.message = error.error
        alert("Id already exist");
      });
  }

  
  



  clearMessage() {
    this.message = ''
  }


}
