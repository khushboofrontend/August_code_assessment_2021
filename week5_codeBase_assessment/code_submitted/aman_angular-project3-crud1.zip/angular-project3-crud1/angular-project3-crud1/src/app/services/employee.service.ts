import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  // apiUrl:string = "http://localhost:5555//"
  apiUrl:string= "http://localhost:5555/employee//"

  constructor(private http: HttpClient) { } 

  getUsers() {
    return this.http.get(this.apiUrl);
  } 

  
}
