import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  employee: any[] = [];
  total_no_of_records:any
  message = ''
  constructor(private empService:EmployeeService) { }

  ngOnInit(): void {// Life cycle hooks
    this.getUserList()
  }

  getUserList = () => {
    this.empService.getUsers().subscribe(
      (result) => {
        this.employee = <any>result;
        this.total_no_of_records = this.employee.length
      },
      (error) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

}
