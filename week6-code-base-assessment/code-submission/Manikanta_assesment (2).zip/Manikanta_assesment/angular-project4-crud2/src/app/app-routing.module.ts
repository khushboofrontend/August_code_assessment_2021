import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { EmployeeCreateComponent } from './components/employee-create/employee-create.component';
import { EmployeeReadComponent } from './components/employee-read/employee-read.component';
import { EmployeeEditComponent } from './components/employee-edit/employee-edit.component';
const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'add', component:EmployeeCreateComponent},
  {path:'read', component:EmployeeReadComponent},
  {path:'contact', component:ContactUsComponent},
  {path:'useredit/:id', component:EmployeeEditComponent},
  {path:'about', component:AboutUsComponent},
  {path:'**', component:PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
