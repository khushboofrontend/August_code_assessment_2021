
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  id:any
    employee_name:string = ''
    date_of_birth:string = ''
    hand_phone_no:any =''
    address:string = ''
    message = ''

  constructor(private http: HttpClient, private router:Router) { }
  // this.router.navigate(['userlist']);

  ngOnInit(): void { 
  }
  addEmployee = () => {
    //alert('You submitted the form')
    let obj = {id:this.id, employee_name:this.employee_name, date_of_birth:this.date_of_birth, hand_phone_no:this.hand_phone_no, address:this.address}

    this.http.post("http://localhost:5555/employee", obj).subscribe(
      (result) => {
        console.log('Inserted')
        console.log(result)
         this.router.navigate(['user-list']);
      }
    )
  }

  clearMessage() {
    this.message = ''
  }

}


