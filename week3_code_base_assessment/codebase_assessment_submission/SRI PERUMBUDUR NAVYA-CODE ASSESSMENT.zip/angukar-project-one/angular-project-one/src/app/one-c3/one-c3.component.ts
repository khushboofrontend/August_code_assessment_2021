import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-c3',
  templateUrl: './one-c3.component.html',
  styleUrls: ['./one-c3.component.css']
})
export class OneC3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
