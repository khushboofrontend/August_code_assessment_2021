import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css']
})
export class UserAddComponent implements OnInit {

  id:any
  user_name:string = ''
  hand_phone_no:any 
   address:any
   date_of_birth: any
   message = ''
   constructor(private http: HttpClient)  { }

  ngOnInit(): void {
  }
  addUser = () => {
    let obj = {id:this.id, user_name:this.user_name, hand_phone_no:this.hand_phone_no, address:this.address,date_of_birth:this.date_of_birth}
    this.http.post("http://localhost:5555/employee", obj).subscribe(
      (result) => {
        console.log('Inserted')
        console.log(result)
      }
    )
  }

  clearMessage() {
    this.message = ''
  }
}
