import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-page-not-found',
  templateUrl: './one-page-not-found.component.html',
  styleUrls: ['./one-page-not-found.component.css']
})
export class OnePageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
