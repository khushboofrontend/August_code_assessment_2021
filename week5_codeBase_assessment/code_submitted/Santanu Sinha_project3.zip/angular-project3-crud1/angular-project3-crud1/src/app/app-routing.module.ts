import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UserListComponent } from './user-list/user-list.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AboutUsComponent } from './about-us/about-us.component';

const routes: Routes = [ 
  {path:'', component:HomePageComponent},
{path:'add-employee', component:AddEmployeeComponent},
{path:'user-list', component:UserListComponent},
{path:'contact', component:ContactUsComponent},
{path:'about', component:AboutUsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
