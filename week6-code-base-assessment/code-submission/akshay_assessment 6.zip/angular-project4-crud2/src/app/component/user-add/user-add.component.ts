import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css']
})
export class UserAddComponent implements OnInit {
  id:any
  employee_name:string = ''
  qualification:string=''
  date_of_birth:any
  resident_phone_no :any
  address:any
  message = ''

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
  }
  addUser = () => {
    alert('You submitted the form')
    let obj = {id:this.id,
       employee_name:this.employee_name, 
       date_of_birth:this.date_of_birth,
       qualification:this.qualification,
        resident_phone_no:this.resident_phone_no,
        address:this.address}

    this.http.post("http://localhost:5555/employee", obj).subscribe(
      (result) => {
        console.log('Inserted')
        console.log(result)
      }
    )
  }

  clearMessage() {
    this.message = ''
  }


}