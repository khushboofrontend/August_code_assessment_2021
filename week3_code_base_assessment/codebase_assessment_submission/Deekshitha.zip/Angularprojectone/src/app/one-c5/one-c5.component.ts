import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-c5',
  templateUrl: './one-c5.component.html',
  styleUrls: ['./one-c5.component.css']
})
export class OneC5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
