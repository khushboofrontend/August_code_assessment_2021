import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from "./../../services/employee.service";
@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {

  id:any
  employee_name:string = ''
  qualification:string = ''
  date_of_birth:string = ''
  resident_phone_no:number=0
  address:any
  message = ''

  constructor(private route: ActivatedRoute, private router: Router, private employeeService:EmployeeService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    })
    this.employeeService.getEmployeeById(this.id)
      .subscribe( data1 => {
        console.log(data1)
        this.employee_name = data1.employee_name;
        this.qualification  = data1.qualification;
        this.date_of_birth  = data1.date_of_birth;
        this.resident_phone_no  = data1.resident_phone_no;
        this.address = data1.address;
      },
      error => {
        alert(error);
      });
  }

  editEmployee() {
    var body = "id=" + this.id 
        + "&employee_name=" + this.employee_name 
        + "&qualification=" + this.qualification 
        + "&date_of_birth=" + this.date_of_birth 
        + "&resident_phone_no=" + this.resident_phone_no 
        + "&address=" + this.address;
    this.employeeService.updateEmployee(body, this.id)
      .subscribe(
        data => {
          this.router.navigate(['employee-list']);
        },
        error => {
          alert(error);
        });
  }

}
