import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeService } from "./../../services/employee.service";

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.css']
})
export class EmployeeCreateComponent implements OnInit {

  id:any
  employee_name:string = ''
  date_of_birth:any = ''
  resident_phone_no:any = ''
  qualification:String=''
  address:any=''
  message = ''

  constructor(private router:Router, private userService:EmployeeService) { }// Dependency Injection

  ngOnInit(): void {
  }

  addUser = () => {
    var body ="id=" + this.id 
    + "&employee_name=" + this.employee_name 
    + "&qualification=" + this.qualification 
        + "&date_of_birth=" + this.date_of_birth
        + "&resident_phone_no=" + this.resident_phone_no 
        + "&address=" + this.address;
    this.userService.createUser(body)
      .subscribe( data => {
        this.router.navigate(['read']);
      },
      (error) => {
        this.message = error.error
        alert("Id already exist");
      });
  }

  clearMessage() {
    this.message = ''
  }
}
