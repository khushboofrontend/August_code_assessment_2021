import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SiteLayoutComponent } from './site-layout/site-layout.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { Parent1Component } from './components/parent1/parent1.component';
import { Child1Component } from './components/child1/child1.component';
import { ParentComponent } from './components/parent/parent.component';
import { ChildComponent } from './components/child/child.component';
const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'sitelayout', component:SiteLayoutComponent},
  {path:'parent1', component:Parent1Component},
  {path:'child1', component:Child1Component},
  {path:'parent', component:ParentComponent},
  {path:'child', component:ChildComponent},
  {path:'**', component:PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
