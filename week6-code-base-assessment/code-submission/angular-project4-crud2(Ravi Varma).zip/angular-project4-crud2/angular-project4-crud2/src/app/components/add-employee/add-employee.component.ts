import { Component, OnInit } from '@angular/core';
import { EmployeeService } from "./../../services/employee.service";
import { Router } from "@angular/router";
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  id:any
  employee_name:string = ''
  qualification:string = ''
  date_of_birth:string = ''
  resident_phone_no:number=0
  address:any
  message = ''

  constructor(private employeeService: EmployeeService, private router: Router) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body = "id=" + this.id
        +"&employee_name=" + this.employee_name 
        + "&qualification=" + this.qualification
        + "&date_of_birth=" + this.date_of_birth 
        + "&resident_phone_no=" + this.resident_phone_no
        + "&address=" + this.address;
        console.log(this.addEmployee)
    this.employeeService.createEmployee(body)
      .subscribe( data => {
        this.router.navigate(['/employee-list']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }
}
