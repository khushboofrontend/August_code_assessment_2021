import { Component, OnInit } from '@angular/core';
import { EmpService } from "./../../service/emp.service";

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  employee:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private empService:EmpService) { }

  ngOnInit(): void {
    this.getEmpList()
  }

  getEmpList = () => {
    this.empService.getemp().subscribe(
      (result) => {
        this.employee = <any>result;
        this.total_no_of_records = this.employee.length
      },
      (error) => {
          if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

   setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}


