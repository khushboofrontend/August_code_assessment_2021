import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  id:any
  employee_name:string = ''
  date_of_birth:any = ''
  hand_phone_number:any = ''
  address:any
  message=''

  constructor(private empService: EmployeeService, private router: Router) { }

  ngOnInit(): void {
  }
  addEmployee = () => {
    var body = "id=" + this.id
        + "&employee_name=" + this.employee_name
        + "&date_of_birth=" + this.date_of_birth
        +"&hand_phone_number=" + this.hand_phone_number
        +"&address=" + this.address;
    this.empService.createEmployee(body)
      .subscribe( data => {
        this.router.navigate(['employee-list']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }

}
